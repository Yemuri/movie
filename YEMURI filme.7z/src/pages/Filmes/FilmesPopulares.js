export default function FilmesPopulares() {
    return (
        <div>
            <h1>Filmes mais Populares</h1>
        </div>
    )
}