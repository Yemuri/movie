export default function FilmesEmCartaz() {
    return (
        <div>
            <h1>Filmes em Cartaz</h1>
        </div>
    )
}