export default function FilmesEstreias() {
    return (
        <div>
            <h1>Estreias</h1>
        </div>
    )
}