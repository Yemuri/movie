export default function SeriesEmCartaz() {
    return (
        <div>
            <h1>Séries em Cartaz</h1>
        </div>
    )
}