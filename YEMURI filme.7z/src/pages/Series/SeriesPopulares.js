export default function SeriesPopulares() {
    return (
        <div>
            <h1>Séries + Populares</h1>
        </div>
    )
}