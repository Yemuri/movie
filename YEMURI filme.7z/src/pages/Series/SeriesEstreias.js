export default function SeriesEstreias() {
    return (
        <div>
            <h1>As mais novas Séries</h1>
        </div>
    )
}