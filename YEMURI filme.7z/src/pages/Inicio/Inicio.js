export default function Inicio() {
    return (
        <div>
            <h1>Página Inicial</h1>
        </div>
    )
}